//
// Created by Fernando Estrada on 30/09/23.
//

#ifndef PROYECTO_1__CD_H
#define PROYECTO_1__CD_H


#include <string>
#include "cancion.h"

class CD {
public:
    CD(const std::string& nombre);
    ~CD();
    void agregarCancion(const Cancion& cancion);
    std::string getNombre() const;
    int getCantidadCanciones() const;

private:
    std::string nombre;
    Cancion* canciones;
    int numCanciones;
};

#endif //PROYECTO_1__CD_H
