#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <filesystem>  // Agregar la biblioteca de manejo de archivos
#include "cancion.h"
#include "cd.h"

namespace fs = std::filesystem;

using namespace std;

bool cargarRespaldos(const string& rutaCarpeta, deque<CD>& listaCDs) {
    // Limpiar la lista de CDs existente
    listaCDs.clear();

    for (const auto& entry : fs::directory_iterator(rutaCarpeta)) {
        if (entry.is_regular_file() && entry.path().extension() == ".txt") {
            ifstream archivo(entry.path());
            if (!archivo) {
                cerr << "Error al abrir el archivo: " << entry.path() << endl;
                continue;
            }

            CD cd(entry.path().filename().stem()); // Usamos el nombre del archivo sin extensión como nombre del CD

            string linea;
            while (getline(archivo, linea)) {
                istringstream ss(linea);
                string nombre, artista, duracion;

                getline(ss, nombre, '|');
                getline(ss, artista, '|');
                getline(ss, duracion);

                Cancion cancion;
                cancion.nombre = nombre;
                cancion.artista = artista;
                cancion.duracion = duracion;

                cd.agregarCancion(cancion);
            }

            listaCDs.push_back(cd);
            archivo.close();
        }
    }

    return true;
}

int main() {
    string rutaCarpeta;
    cout << "Porfavor Asegurarse que los CD es esten una carpeta especifica \n";
    cout << "Ingresar de la siguiente manera:\n";
    cout << "Caso Mac: /Users/fernandoestrada/Downloads/CD \n";
    cout << "Caso Windows: C:\\Users\\fernandoestrada\\Downloads\\CD \n";
    cout << "Ingrese la ruta de la carpeta de respaldos: ";
    cin >> rutaCarpeta;

    deque<CD> listaCDs;
    if (cargarRespaldos(rutaCarpeta, listaCDs)) {
        cout << "Respaldos cargados exitosamente." << endl;
        cout << "CDs encontrados:" << endl;
        for (const CD& cd : listaCDs) {
            cout << "Nombre del CD: " << cd.getNombre() << endl;
            cout << "Cantidad de canciones: " << cd.getCantidadCanciones() << endl;
            cout << "--------------------------" << endl;
        }
    }

    return 0;
}
