//
// Created by Fernando Estrada on 30/09/23.
//

// cd.cpp
// cd.cpp
#include "cd.h"

CD::CD(const std::string& nombre) : nombre(nombre), canciones(nullptr), numCanciones(0) {}

CD::~CD() {
    delete[] canciones;
}

// Implementación actualizada del método agregarCancion
void CD::agregarCancion(const Cancion& cancion) {
    if (!canciones) {
        canciones = new Cancion[1];
        canciones[0] = cancion;
        numCanciones = 1;
    } else {
        // Crear un nuevo arreglo con espacio para una canción adicional
        Cancion* temp = new Cancion[numCanciones + 1];

        // Copiar las canciones existentes al nuevo arreglo
        for (int i = 0; i < numCanciones; i++) {
            temp[i] = canciones[i];
        }

        // Agregar la nueva canción al final del nuevo arreglo
        temp[numCanciones] = cancion;

        // Liberar la memoria del arreglo anterior
        delete[] canciones;

        // Apuntar al nuevo arreglo
        canciones = temp;

        // Incrementar el contador de canciones
        numCanciones++;
    }
}

std::string CD::getNombre() const {
    return nombre;
}

int CD::getCantidadCanciones() const {
    return numCanciones;
}
