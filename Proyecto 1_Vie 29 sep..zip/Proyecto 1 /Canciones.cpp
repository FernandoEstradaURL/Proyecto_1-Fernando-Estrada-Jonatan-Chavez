//
// Created by Fernando Estrada on 28/09/23.
//

#include "Canciones.h"

Canciones::Canciones(const std::string& nombre, const std::string& artista, const std::string& duracion)
        : nombre(nombre), artista(artista), duracion(duracion) {}