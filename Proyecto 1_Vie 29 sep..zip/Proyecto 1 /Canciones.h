//
// Created by Fernando Estrada on 28/09/23.
//

#ifndef PROYECTO_1__CANCIONES_H
#define PROYECTO_1__CANCIONES_H

#include <string>

class Canciones {

public:
    std::string nombre;
    std::string artista;
    std::string duracion;

    Canciones(const std::string& nombre, const std::string& artista, const std::string& duracion);
};


#endif //PROYECTO_1__CANCIONES_H
