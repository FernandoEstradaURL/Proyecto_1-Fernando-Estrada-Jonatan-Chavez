//
// Created by Fernando Estrada on 30/09/23.
//

// cd.cpp
#include "cd.h"

CD::CD(const std::string& nombre) : nombre(nombre), canciones(nullptr), numCanciones(0) {}

CD::~CD() {
    delete[] canciones;
}

void CD::agregarCancion(const Cancion& cancion) {
    if (!canciones) {
        canciones = new Cancion[1];
        canciones[0] = cancion;
    } else {
        Cancion* temp = new Cancion[numCanciones + 1];
        for (int i = 0; i < numCanciones; i++) {
            temp[i] = canciones[i];
        }
        delete[] canciones;
        canciones = temp;
        canciones[numCanciones] = cancion;
    }
    numCanciones++;
}

std::string CD::getNombre() const {
    return nombre;
}

int CD::getCantidadCanciones() const {
    return numCanciones;
}
