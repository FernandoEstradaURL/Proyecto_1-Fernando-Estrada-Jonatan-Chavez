#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>


#include "cancion.h"
#include "cd.h"

using namespace std;

bool cargarRespaldos(const string& rutaCarpeta, deque<CD>& listaCDs) {
    // Limpiar la lista de CDs existente
    listaCDs.clear();

    ifstream carpeta(rutaCarpeta);
    if (!carpeta) {
        cerr << "Error al abrir la carpeta: " << rutaCarpeta << endl;
        return false;
    }
}


int main() {




    return 0;
}
