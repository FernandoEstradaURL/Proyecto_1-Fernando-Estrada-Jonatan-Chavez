//
// Created by Fernando Estrada on 30/09/23.
//

// cancion.h
#ifndef CANCION_H
#define CANCION_H

#include <string>

struct Cancion {
    std::string nombre;
    std::string artista;
    std::string duracion;
};

#endif // CANCION_H



