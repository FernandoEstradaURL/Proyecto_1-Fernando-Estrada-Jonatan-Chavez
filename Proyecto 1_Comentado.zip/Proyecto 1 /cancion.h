//
// Created by Fernando Estrada on 30/09/23.
//

// cancion.h
#ifndef CANCION_H
#define CANCION_H

#include <string>

// Definición de la estructura Cancion
struct Cancion {
    std::string titulo;     // Título de la canción
    std::string artista;    // Nombre del artista
    std::string duracion;   // Duración de la canción en formato de cadena
    Cancion* siguiente;    // Puntero al siguiente nodo en la lista enlazada
};

#endif // CANCION_H



