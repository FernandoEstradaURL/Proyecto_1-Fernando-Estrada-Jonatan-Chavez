//
// Created by Fernando Estrada on 30/09/23.
//

#ifndef PROYECTO_1__CD_H
#define PROYECTO_1__CD_H


#include <string>
#include <vector>
#include "cancion.h"

class CD {
public:
    // Constructor que recibe el nombre del CD
    void mostrarCanciones() const;
    CD(const std::string& nombre);

    // Método para agregar una canción al CD
    void agregarCancion(const Cancion& cancion);

    // Método para obtener el nombre del CD
    const std::string& obtenerNombre() const;

    // Método para obtener la cantidad de canciones en el CD
    int obtenerCantidadCanciones() const;

    // Método para obtener una canción por índice
    const Cancion& obtenerCancion(int indice) const;

    // Destructor para liberar memoria
    ~CD();

private:
    std::string nombre_;
    std::vector<Cancion> canciones_;
};



#endif //PROYECTO_1__CD_H
