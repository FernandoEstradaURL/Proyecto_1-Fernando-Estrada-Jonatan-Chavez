//
// Created by Fernando Estrada on 30/09/23.
//

// cd.cpp
// cd.cpp
#include "cd.h"
#include <iostream> /

CD::CD(const std::string& nombre) : nombre_(nombre) {}

void CD::agregarCancion(const Cancion& cancion) {
    canciones_.push_back(cancion);
}

const std::string& CD::obtenerNombre() const {
    return nombre_;
}

int CD::obtenerCantidadCanciones() const {
    return canciones_.size();
}

const Cancion& CD::obtenerCancion(int indice) const {
    return canciones_[indice];
}

void CD::mostrarCanciones() const {
    for (int i = 0; i < canciones_.size(); ++i) {
        const Cancion& cancion = canciones_[i];
        std::cout << "Canción " << (i + 1) << ":" << std::endl;
        std::cout << "   Título: " << cancion.titulo << std::endl;
        std::cout << "   Artista: " << cancion.artista << std::endl;
        std::cout << "   Duración: " << cancion.duracion << std::endl;
    }
}

CD::~CD() {

}

