#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <deque>
#include <vector>
#include <filesystem>
#include "cancion.h"
#include "cd.h"

namespace fs = std::filesystem;

using namespace std;

// Estructura para representar un problema en un archivo
struct ProblemaArchivo {
    string nombreArchivo;
    string problema;
};

// Función para cargar respaldos y gestionar problemas
bool cargarRespaldos(const string& rutaCarpeta, deque<CD*>& listaCDs, deque<ProblemaArchivo>& problemas) {
    // Limpiar la lista de CDs existente
    for (CD* disco : listaCDs) {
        delete disco;
    }
    listaCDs.clear();
    problemas.clear();


    for (const auto& entrada : fs::directory_iterator(rutaCarpeta)) {
        if (entrada.is_regular_file() && entrada.path().extension() == ".txt") {
            ifstream archivo(entrada.path());
            if (!archivo) {
                cerr << "Error al abrir el archivo: " << entrada.path() << endl;
                continue;
            }

            // Verificar si el archivo está vacío
            if (archivo.peek() == ifstream::traits_type::eof()) {
                cerr << "Archivo vacío: " << entrada.path() << endl;
                archivo.close();
                continue;
            }

            CD* disco = new CD(entrada.path().filename().stem()); // Usamos el nombre del archivo sin extensión como nombre del CD

            string linea;
            int numeroLinea = 0;
            while (getline(archivo, linea)) {
                numeroLinea++;

                istringstream ss(linea);
                string nombre, artista, duracion;


                // Verificar si el formato de línea es incorrecto
                if (!(getline(ss, nombre, '|') && getline(ss, artista, '|') && getline(ss, duracion))) {
                    ProblemaArchivo problema;
                    problema.nombreArchivo = entrada.path().string();
                    problema.problema = "Formato de línea incorrecto";
                    problemas.push_back(problema);
                    cerr << "Formato de línea incorrecto en archivo: " << entrada.path() << " (Línea " << numeroLinea << ")" << endl;
                    archivo.close();
                    delete disco; // Liberar memoria antes de continuar con el siguiente archivo
                    continue;
                }

                Cancion cancion;
                cancion.titulo = nombre;
                cancion.artista = artista;
                cancion.duracion = duracion;

                disco->agregarCancion(cancion);
            }

            listaCDs.push_back(disco);
            archivo.close();
        }
    }

    return true;
}

// Función para mostrar la lista de CDs
void mostrarListaCDs(const deque<CD*>& listaCDs) {
    cout << "CDs disponibles:" << endl;
    int i = 1;
    for (const CD* disco : listaCDs) {
        cout << i << ". Nombre del CD: " << disco->obtenerNombre() << endl;
        cout << "   Cantidad de canciones: " << disco->obtenerCantidadCanciones() << endl;
        i++;
    }
}

// Función para mostrar la cola de reproducción
void mostrarColaReproduccion(const deque<Cancion>& colaReproduccion) {
    cout << "Cola de Reproducción:" << endl;
    for (const Cancion& cancion : colaReproduccion) {
        cout << "   " << cancion.titulo << " - " << cancion.artista << endl;
    }
}

// Función para ordenar la cola de reproducción por título de canción
void ordenarColaReproduccion(deque<Cancion>& colaReproduccion) {
    sort(colaReproduccion.begin(), colaReproduccion.end(), [](const Cancion& a, const Cancion& b) {
        return a.titulo < b.titulo;
    });
}

int main() {
    string rutaCarpeta;
    cout << "Por favor, asegúrese de que los CDs estén en una carpeta específica." << endl;
    cout << "Formato de Ingreso: /Users/su usuario/Ubicacion/Nombre de la carpeta -> /Users/fernandoestrada/Downloads/CD  " << endl;
    cout << "Ingrese la ruta de la carpeta de respaldos: ";
    cin >> rutaCarpeta;

    deque<CD*> listaCDs;
    deque<ProblemaArchivo> problemas;
    deque<Cancion> colaReproduccion;

    if (cargarRespaldos(rutaCarpeta, listaCDs, problemas)) {

        cout << "Respaldos cargados exitosamente." << endl;
        cout << "CDs encontrados:" << endl;
        mostrarListaCDs(listaCDs);
        cout << "--------------------------" << endl;


        while (true) {
            cout << "Seleccione una opción:" << endl;
            cout << "1. Agregar Canción" << endl;
            cout << "2. Ver Cola de Reproducción" << endl;
            cout << "3. Ordenar Cola de Reproducción" << endl;
            cout << "4. Reproducción Actual" << endl;
            cout << "5. Reproducir Siguiente" << endl;
            cout << "6. Salir" << endl;

            cout << "Errores Encontrados:" << endl;

            int opcion;
            cin >> opcion;

            switch (opcion) {
                case 1: {
                    mostrarListaCDs(listaCDs);
                    int seleccion;
                    cout << "Seleccione un CD: ";
                    cin >> seleccion;
                    if (seleccion >= 1 && seleccion <= listaCDs.size()) {
                        const CD* cdSeleccionado = listaCDs[seleccion - 1];
                        cout << "Canciones del CD:" << endl;
                        cdSeleccionado->mostrarCanciones();
                        int seleccionCancion;
                        cout << "Seleccione una canción: ";
                        cin >> seleccionCancion;
                        if (seleccionCancion >= 1 && seleccionCancion <= cdSeleccionado->obtenerCantidadCanciones()) {
                            colaReproduccion.push_back(cdSeleccionado->obtenerCancion(seleccionCancion - 1));
                            cout << "Canción agregada a la cola de reproducción." << endl;
                        } else {
                            cout << "Selección de canción inválida." << endl;
                        }
                    } else {
                        cout << "Selección de CD inválida." << endl;
                    }
                    break;
                }
                case 2: {
                    mostrarColaReproduccion(colaReproduccion);
                    break;
                }
                case 3: {
                    ordenarColaReproduccion(colaReproduccion);
                    cout << "Cola de reproducción ordenada por título de canción." << endl;
                    break;
                }
                case 4: {
                    if (!colaReproduccion.empty()) {
                        cout << "Reproducción Actual:" << endl;
                        cout << "   " << colaReproduccion.front().titulo << " - " << colaReproduccion.front().artista << endl;
                    } else {
                        cout << "La cola de reproducción está vacía." << endl;
                    }
                    break;
                }
                case 5: {
                    if (!colaReproduccion.empty()) {
                        cout << "Reproduciendo: " << colaReproduccion.front().titulo << " - " << colaReproduccion.front().artista << endl;
                        colaReproduccion.pop_front();
                    } else {
                        cout << "La cola de reproducción está vacía." << endl;
                    }
                    break;
                }
                case 6: {
                    // Limpiar la memoria de CDs
                    for (CD* disco : listaCDs) {
                        delete disco;
                    }
                    listaCDs.clear();
                    // Salir del programa
                    return 0;
                }
                default:
                    cout << "Opción inválida." << endl;
            }
        }

    } else {
        cout << "Error al cargar respaldos." << endl;
    }

    return 0;
}
