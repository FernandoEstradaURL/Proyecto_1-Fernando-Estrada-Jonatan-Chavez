//
// Created by Fernando Estrada on 30/09/23.
//

// cancion.h
#ifndef CANCION_H
#define CANCION_H

#include <string>

struct Cancion {
    std::string titulo;
    std::string artista;
    std::string duracion;
    Cancion* siguiente; // Puntero al siguiente nodo en la lista enlazada
};

#endif // CANCION_H



