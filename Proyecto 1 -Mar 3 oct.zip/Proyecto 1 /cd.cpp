//
// Created by Fernando Estrada on 30/09/23.
//

// cd.cpp
// cd.cpp
#include "cd.h"

CD::CD(const std::string& nombre) : nombre_(nombre), canciones_(nullptr), cantidadCanciones_(0) {}

void CD::agregarCancion(const Cancion& cancion) {
    // Añadir la canción al final de la lista enlazada
    Cancion* nuevaCancion = new Cancion(cancion);
    nuevaCancion->siguiente = canciones_;
    canciones_ = nuevaCancion;
    cantidadCanciones_++;
}

const std::string& CD::obtenerNombre() const {
    return nombre_;
}

int CD::obtenerCantidadCanciones() const {
    return cantidadCanciones_;
}

const Cancion* CD::obtenerCanciones() const {
    return canciones_;
}

CD::~CD() {
    // Liberar la memoria de las canciones
    while (canciones_ != nullptr) {
        Cancion* siguiente = canciones_->siguiente;
        delete canciones_;
        canciones_ = siguiente;
    }
}
