#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <deque>
#include <filesystem>
#include "cancion.h"
#include "cd.h"

namespace fs = std::filesystem;

using namespace std;

// Estructura para representar un problema en un archivo
struct ProblemaArchivo {
    string nombreArchivo;
    string problema;
};

int main() {
    string rutaCarpeta;
    cout << "Por favor, asegúrese de que los CDs estén en una carpeta específica." << endl;
    cout << "Ingrese la ruta de la carpeta de respaldos: ";
    cin >> rutaCarpeta;

    deque<CD*> listaCDs;
    deque<ProblemaArchivo> problemas;

    for (const auto& entrada : fs::directory_iterator(rutaCarpeta)) {
        if (entrada.is_regular_file() && entrada.path().extension() == ".txt") {
            ifstream archivo(entrada.path());
            if (!archivo) {
                cerr << "Error al abrir el archivo: " << entrada.path() << endl;
                continue;
            }

            // Verificar si el archivo está vacío
            if (archivo.peek() == ifstream::traits_type::eof()) {
                cerr << "Archivo vacío: " << entrada.path() << endl;
                archivo.close();
                continue;
            }

            CD* disco = new CD(entrada.path().filename().stem()); // Usamos el nombre del archivo sin extensión como nombre del CD

            string linea;
            while (getline(archivo, linea)) {
                istringstream ss(linea);
                string nombre, artista, duracion;

                if (getline(ss, nombre, '|') && getline(ss, artista, '|') && getline(ss, duracion)) {
                    Cancion cancion;
                    cancion.titulo = nombre;
                    cancion.artista = artista;
                    cancion.duracion = duracion;

                    disco->agregarCancion(cancion);
                } else {
                    ProblemaArchivo problema;
                    problema.nombreArchivo = entrada.path().string();
                    problema.problema = "Formato de línea incorrecto";
                    problemas.push_back(problema);
                    cerr << "Formato de línea incorrecto en archivo: " << entrada.path() << endl;
                }
            }

            listaCDs.push_back(disco);
            archivo.close();
        }
    }

    cout << "Respaldos cargados exitosamente." << endl;
    cout << "CDs encontrados:" << endl;
    for (const CD* disco : listaCDs) {
        cout << "Nombre del CD: " << disco->obtenerNombre() << endl;
        cout << "Cantidad de canciones: " << disco->obtenerCantidadCanciones() << endl;
        cout << "--------------------------" << endl;
        delete disco; // Liberar memoria después de mostrar la información
    }

    // Mostrar problemas
    cout << "Problemas encontrados:" << endl;
    for (const ProblemaArchivo& problema : problemas) {
        cout << "Archivo: " << problema.nombreArchivo << " - Problema: " << problema.problema << endl;
    }

    return 0;
}
