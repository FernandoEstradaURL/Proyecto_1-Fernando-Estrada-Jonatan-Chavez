//
// Created by Fernando Estrada on 30/09/23.
//

#ifndef PROYECTO_1__CD_H
#define PROYECTO_1__CD_H


#include <string>
#include "cancion.h"

class CD {
    public:
        CD(const std::string& nombre);

        void agregarCancion(const Cancion& cancion);

        const std::string& obtenerNombre() const;

        int obtenerCantidadCanciones() const;

        // Función para obtener la lista de canciones
        const Cancion* obtenerCanciones() const;

        // Destructor para liberar memoria
        ~CD();

    private:
        std::string nombre_;
        Cancion* canciones_;
        int cantidadCanciones_;
    };


#endif //PROYECTO_1__CD_H
